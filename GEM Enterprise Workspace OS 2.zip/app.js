/* GEM Enterprise — Workspace OS · multi-workspace SPA (router + renderers + interactions) */
(function () {
  'use strict';

  /* ============ ICONS ============ */
  const I = {
    grid:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>',
    users:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13A4 4 0 0 1 16 11"/></svg>',
    db:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v6c0 1.7 4 3 9 3s9-1.3 9-3V5M3 11v6c0 1.7 4 3 9 3s9-1.3 9-3v-6"/></svg>',
    chart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M7 14l4-4 4 4 4-6"/></svg>',
    bars:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M18.7 8L14 12.7l-3-3-5 5"/></svg>',
    spark:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l2.4 7.2L22 12l-7.6 2.8L12 22l-2.4-7.2L2 12l7.6-2.8z"/></svg>',
    link:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>',
    shield:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    gear:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 7 19.4l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.6 1.6 0 0 0 4.6 14H4.5a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 6 7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.6 1.6 0 0 0 12 3.4V3.3a2 2 0 1 1 4 0v.1A1.6 1.6 0 0 0 19.4 7l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.6 1.6 0 0 0 21 14h.1a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.6 1z"/></svg>',
    radar:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19.07 4.93A10 10 0 1 0 12 22"/><path d="M16.24 7.76A6 6 0 1 0 12 18"/><path d="M12 12l9-9"/></svg>',
    store:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l2-5h14l2 5"/><path d="M3 9v11a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V9"/><path d="M3 9h18"/><path d="M9 21V12h6v9"/></svg>',
    doc:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/></svg>',
    bolt:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2 3 14h7l-1 8 10-12h-7z"/></svg>',
    flag:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><path d="M4 22v-7"/></svg>',
    eye:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
    key:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-3 3l-9 9m0 0a3 3 0 1 0 4 4m-4-4l-3 3a3 3 0 0 0 4 4"/></svg>',
    arrow:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>',
    chev:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>',
    plus:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>',
    mail:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m2 7 10 6 10-6"/></svg>',
    lock:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
    heart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/></svg>',
    scale:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v18M5 7H2M7 7l5-4 5 4M5 7l-2 7a4 4 0 0 0 4 0L5 7zM19 7l-2 7a4 4 0 0 0 4 0L19 7z"/></svg>',
    cart:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.6L23 6H6"/></svg>',
    search:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>',
    bell:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/></svg>',
    close:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>'
  };

  /* ============ WORKSPACES + MODULES ============ */
  const WORKSPACES = [
    { id:'hq', name:'GEM Enterprise HQ', short:'GE', role:'Super Admin · Organization', color:'#0c6a42',
      desc:'Organization-level control center managing all workspaces, services, threat monitoring, and governance across the enterprise.',
      modules:['overview','threats','cyber','realestate','stores','clients','prod','marketing','sales','ai','integrations','community','security','settings'] },
    { id:'iww', name:'Infinite Wealth & Wellbeing', short:'IW', role:'Workspace Admin · Tenant', color:'#1d7a8c',
      desc:'Client service workspace for the Infinite Wealth & Wellbeing engagement — cybersecurity, real estate & legal portfolio, and community delivery.',
      modules:['overview','threats','cyber','realestate','stores','community','ai','integrations','security','settings'] },
    { id:'family', name:'GEM Family Protection', short:'FP', role:'Workspace Admin · Tenant', color:'#8a6a17',
      desc:'Member and community workspace for the Family Protection plan — scam & fraud monitoring, incident intake, plans, and support requests.',
      modules:['overview','threats','plans','realestate','stores','community','ai','integrations','settings'] }
  ];
  const MODULE_DEFS = {
    overview:{label:'Overview',icon:'grid'}, threats:{label:'Threat & Monitoring',icon:'radar'}, cyber:{label:'Cybersecurity',icon:'shield'},
    realestate:{label:'Real Estate & Legal',icon:'scale'}, stores:{label:'Store Management',icon:'store'}, plans:{label:'Protection Plans',icon:'heart'},
    clients:{label:'Workspaces & Clients',icon:'users'}, prod:{label:'Production & Dev',icon:'db'}, marketing:{label:'Marketing Studio',icon:'chart'},
    sales:{label:'Sales CRM',icon:'bars'}, ai:{label:'AI Services',icon:'spark'}, integrations:{label:'Automations & Apps',icon:'link'},
    community:{label:'Community',icon:'users'}, security:{label:'Security & Compliance',icon:'lock'}, settings:{label:'Settings & Billing',icon:'gear'}
  };
  const GROUPS = {
    primary:['overview','threats','cyber','realestate','stores','plans','clients','prod','marketing','sales','community','ai'],
    platform:['integrations'], governance:['security','settings']
  };

  /* ============ THREAT DATA ============ */
  const SURFACES = [
    {name:'Email',icon:'mail',use:'Inbound phishing & malicious attachments'},
    {name:'URLs & Links',icon:'link',use:'Reputation & sandbox detonation'},
    {name:'Files',icon:'doc',use:'Malware & hash analysis'},
    {name:'Identity',icon:'key',use:'Logins, impossible travel, ATO'},
    {name:'Payments',icon:'bolt',use:'Fraud & chargeback signals'},
    {name:'Stores',icon:'store',use:'Scam listings & impersonation'},
    {name:'Domains',icon:'flag',use:'Brand abuse & DGA detection'},
    {name:'Credentials',icon:'lock',use:'Breach & stuffing exposure'}
  ];
  const FEEDS = [
    {name:'VirusTotal',desc:'File, URL, and domain reputation across 70+ scanners',cat:'Reputation'},
    {name:'URLScan.io',desc:'URL scanning, sandbox screenshots, and behavior',cat:'URL scan'},
    {name:'AbuseIPDB',desc:'Malicious IP reputation and abuse reports',cat:'IP reputation'},
    {name:'PhishTank',desc:'Community-verified phishing URL database',cat:'Phishing'},
    {name:'Google Safe Browsing',desc:'Malware and social-engineering lists',cat:'Browsing'},
    {name:'Have I Been Pwned',desc:'Breach exposure and credential leaks',cat:'Identity'},
    {name:'AlienVault OTX',desc:'Open threat-exchange indicators of compromise',cat:'Threat intel'},
    {name:'MISP',desc:'Open-source threat-intel sharing platform',cat:'Threat intel'},
    {name:'WHOIS / RDAP',desc:'Domain registration and ownership data',cat:'Domain intel'}
  ];
  const PLAYBOOKS = [
    {name:'Phishing URL Triage',stages:['Ingest','Enrich','Sandbox','Severity','Contain','Notify']},
    {name:'Malware Attachment Review',stages:['Extract','Detonate','Reputation','Score','Contain']},
    {name:'Credential Stuffing & ATO',stages:['Detect','Enrich','Verify','Reset','Notify']},
    {name:'Payment Fraud Response',stages:['Flag','Score','Review','Hold','Escalate']},
    {name:'Suspicious Login / Impossible Travel',stages:['Detect','Geo','Risk','Challenge','Block']},
    {name:'Store Impersonation & Scam Listing',stages:['Report','Verify','Takedown','Block']},
    {name:'Brand & Domain Abuse',stages:['Monitor','Match','Evidence','Escalate']},
    {name:'Client Incident Escalation',stages:['Triage','Assign','Contain','Brief','Close']}
  ];

  /* ============ STORE CONNECTORS ============ */
  const STORES = [
    {name:'TikTok Shop',desc:'Social commerce orders & products',color:'#000000'},
    {name:'Shopify',desc:'Storefront, orders, and payouts',color:'#5a8a3a'},
    {name:'Google Merchant Center',desc:'Product feeds & Shopping ads',color:'#1f5f86'},
    {name:'Google Business Profile',desc:'Listings, reviews & location',color:'#1d7a8c'},
    {name:'WooCommerce',desc:'WordPress store orders',color:'#7a3a9a'},
    {name:'Amazon',desc:'Marketplace listings & orders',color:'#b5651d'},
    {name:'eBay',desc:'Marketplace listings',color:'#9a2d3f'},
    {name:'Etsy',desc:'Handmade & vintage marketplace',color:'#8a4f2c'},
    {name:'Walmart Marketplace',desc:'Marketplace orders',color:'#2c7a4f'},
    {name:'Stripe',desc:'Payments & payouts',color:'#4a3a8c'},
    {name:'PayPal',desc:'Payments & disputes',color:'#1d7a8c'}
  ];

  /* ============ INTEGRATION CATALOG (196 apps) ============ */
  const CATS = [
    {key:'communication',label:'Communication',color:'#2c7a4f'},{key:'crm',label:'CRM & Sales',color:'#1f5f86'},
    {key:'marketing',label:'Marketing',color:'#a23a6a'},{key:'payments',label:'Payments & Billing',color:'#8a6a17'},
    {key:'devtools',label:'Developer Tools',color:'#5e3a9a'},{key:'analytics',label:'Analytics',color:'#1d7a8c'},
    {key:'productivity',label:'Productivity',color:'#3a6b5e'},{key:'support',label:'Customer Support',color:'#b5651d'},
    {key:'hr',label:'HR & People',color:'#8a4f2c'},{key:'accounting',label:'Accounting & Finance',color:'#4a6b2a'},
    {key:'storage',label:'Storage & Files',color:'#3a5a6b'},{key:'design',label:'Design & Creative',color:'#9a3a6b'},
    {key:'security',label:'Security & Compliance',color:'#2f7a3b'},{key:'projects',label:'Project Management',color:'#4a3a8c'}
  ];
  const USE = {
    communication:{Slack:'Team channels, DMs, and workflow notifications','Microsoft Teams':'Chat, meetings, and file collaboration in Microsoft 365',Discord:'Community servers, voice channels, and member engagement',Zoom:'Video meetings, webinars, and recordings','Google Meet':'Video conferencing with Google Workspace',Webex:'Enterprise video meetings and calling',Twilio:'Programmable SMS, voice, and WhatsApp messaging',SendGrid:'Transactional and marketing email delivery',Mailgun:'Email routing, sending, and validation',Intercom:'Customer messaging, support, and onboarding',Front:'Shared inbox for team email and messaging',Spike:'Conversational email and team chat',Chatwork:'Group chat, tasks, and file sharing',Mattermost:'Self-hosted secure team messaging'},
    crm:{HubSpot:'CRM, marketing, and service hub in one platform',Salesforce:'Enterprise CRM with sales cloud and automation',Pipedrive:'Visual sales pipeline and deal tracking','Zoho CRM':'Multichannel CRM with sales automation',Copper:'Google Workspace-native CRM',Freshsales:'AI-powered CRM with built-in phone and email',Capsule:'Simple contact and pipeline management',Nimble:'Social contact management and enrichment',Close:'Inside sales CRM with calling and sequences',Keap:'Small business CRM with marketing automation',ActiveCampaign:'CRM with email and marketing automation',Streak:'CRM built into Gmail',Attio:'Flexible, data-driven CRM and record system',Folk:'Lightweight contact and relationship management'},
    marketing:{Mailchimp:'Email marketing and audience management',Brevo:'Email, SMS, and marketing automation',ConvertKit:'Creator-focused email and newsletters',Klaviyo:'Ecommerce email and SMS personalization',GetResponse:'Email, funnels, and webinars',AWeber:'Email marketing and landing pages','Campaign Monitor':'Branded email and journey automation','Constant Contact':'Email and digital marketing for SMBs',Omnisend:'Ecommerce SMS and email automation',Drip:'Ecommerce CRM and behavioral email',MailerLite:'Email, automations, and landing pages',Moosend:'Email and marketing automation',Mailjet:'Email and SMS collaboration platform',Beehiiv:'Newsletter publishing and monetization'},
    payments:{Stripe:'Online payments, subscriptions, and billing',PayPal:'Global payments and checkout',Square:'Payments, POS, and commerce tools',Adyen:'Enterprise omnichannel payments',Razorpay:'Indian payments and payouts',Klarna:'Buy now, pay later and checkout',Mollie:'European payment methods for the web',GoCardless:'Bank debit and recurring payments',Recurly:'Subscription billing and management',Chargebee:'Recurring billing and revenue operations',Paddle:'Payments, tax, and subscription management','Lemon Squeezy':'Merchant of record for digital products',Braintree:'PayPal-owned global payment gateway',Paystack:'African payments and recurring billing'},
    devtools:{GitHub:'Git repositories, CI/CD, and code review',GitLab:'DevSecOps platform with CI/CD and registries',Bitbucket:'Git repos and Jira integration',Vercel:'Frontend hosting and deployments',Netlify:'Static and serverless web hosting',Render:'Fullstack app hosting and background jobs',Heroku:'Managed app runtime and add-ons',AWS:'Cloud compute, storage, and infrastructure','Google Cloud':'Cloud compute and data services','Microsoft Azure':'Cloud services and enterprise infrastructure',Docker:'Containerization and image registry',Cloudflare:'CDN, edge, DNS, and security',Sentry:'Error monitoring and performance tracing',Datadog:'Observability, metrics, and infrastructure monitoring'},
    analytics:{'Google Analytics':'Web and app traffic analytics',Mixpanel:'Product and event analytics',Amplitude:'Product analytics and behavioral cohorts',Heap:'Autocapture product analytics',Plausible:'Privacy-friendly simple web analytics',Fathom:'Cookie-free simple analytics',PostHog:'Product analytics, feature flags, and replay',Segment:'Customer data platform and event routing',Hotjar:'Heatmaps, recordings, and feedback','Microsoft Clarity':'Free session recordings and heatmaps',Matomo:'Privacy-focused web analytics',ChartMogul:'Subscription and revenue analytics',Baremetrics:'Stripe analytics and MRR metrics',ProfitWell:'Recurring revenue and retention analytics'},
    productivity:{Notion:'Docs, wikis, and project workspace',Coda:'Docs with data and built-in buttons',Airtable:'Database-spreadsheet hybrid and apps',Asana:'Task and project management',Trello:'Kanban boards and cards','ClickUp':'All-in-one task and docs platform','Monday.com':'Visual work OS for projects',Todoist:'Task lists and productivity',TickTick:'Tasks, habits, and calendar',Obsidian:'Local linked knowledge base',Logseq:'Outliner and knowledge graph',Bear:'Markdown notes for Apple devices',Craft:'Structured documents and notes',Capacities:'Object-based personal knowledge base'},
    support:{Zendesk:'Help desk, ticketing, and support suite',Freshdesk:'Ticketing and multichannel support','Help Scout':'Shared inbox and knowledge base',Crisp:'Live chat, chatbot, and CRM',Tidio:'Live chat and chatbots for SMBs',LiveChat:'Live chat and help desk',Olark:'Live chat and visitor insights','Zoho Desk':'Context-aware help desk',Kayako:'Help desk and customer journey',HappyFox:'Help desk and ticket management',Gorgias:'Ecommerce help desk and automation',Reamaze:'Help desk and customer chat',SupportBee:'Simple shared inbox support',HelpCrunch:'Live chat, knowledge base, and popups'},
    hr:{BambooHR:'HRIS, employee records, and onboarding',Workday:'Enterprise HCM, payroll, and finance',Gusto:'Payroll, benefits, and HR',Rippling:'HR, IT, and payroll platform',Deel:'Global hiring, payroll, and compliance',Remote:'International payroll and contractor management',Personio:'European HR software and recruiting',Hibob:'People management and culture platform',Namely:'HR, payroll, and benefits',Greenhouse:'Structured recruiting and hiring',Lever:'ATS and recruiting CRM',Workable:'Hiring and applicant tracking',Ashby:'All-in-one recruiting platform',Teamtailor:'Recruitment marketing and ATS'},
    accounting:{'QuickBooks':'Small business accounting',Xero:'Cloud accounting and bookkeeping',Wave:'Free accounting and invoicing',FreshBooks:'Invoicing and expense tracking','Sage Intacct':'Cloud financial management','Zoho Books':'Online accounting software',NetSuite:'ERP and financial management',FreeAgent:'Freelancer and small business accounting',Tipalti:'Global payables and mass payments',Ramp:'Corporate cards and spend management',Brex:'Finance platform and corporate cards',Mercury:'Business banking for startups',Wise:'Multi-currency business account',Expensify:'Expense reports and receipt tracking'},
    storage:{'Google Drive':'Cloud storage and file sharing',Dropbox:'File storage, sync, and sharing',OneDrive:'Microsoft cloud storage',Box:'Enterprise content and file management','iCloud Drive':'Apple cloud storage and sync',Mega:'Encrypted cloud storage',pCloud:'Secure cloud storage and backup',Tresorit:'End-to-end encrypted file sharing',Backblaze:'Cloud backup and B2 storage',Wasabi:'Hot cloud storage at low cost','AWS S3':'Object storage for apps and data',Cloudinary:'Image and video management',Filestack:'File upload and transformation API','Frame.io':'Video review and collaboration'},
    design:{Figma:'Collaborative interface design and prototyping',Canva:'Graphic design and templates','Adobe Creative Cloud':'Professional design and creative apps',Sketch:'Mac UI and icon design',Framer:'Interactive web design and publishing',Webflow:'Visual web development and CMS',Dribbble:'Design portfolio and inspiration',Behance:'Creative portfolio showcase',Unsplash:'Free stock photography',Pexels:'Free stock photos and videos',Loom:'Screen recording and async video',CleanShot:'Screenshots and screen recording for Mac',Pitch:'Collaborative presentations',Gamma:'AI documents and presentations'},
    security:{'1Password':'Password manager and secrets vault',Bitwarden:'Open-source password management',Okta:'Identity and access management',Auth0:'Customer identity and authentication','Cloudflare Access':'Zero-trust access to internal apps',Snyk:'Developer security and dependency scanning',SonarQube:'Code quality and security scanning','HashiCorp Vault':'Secrets and sensitive data management',Tailscale:'Mesh VPN and secure networking',Twingate:'Zero-trust network access',Vanta:'Compliance automation and SOC 2',Lacework:'Cloud security and compliance','Datadog Security':'Cloud and runtime threat detection',CrowdStrike:'Endpoint protection and XDR'},
    projects:{Linear:'Issue tracking and product development',Jira:'Project and issue tracking for teams',Confluence:'Team docs and knowledge base','ClickUp':'Tasks, docs, and goals',Asana:'Work and project management','Monday.com':'Visual work and project management',Notion:'Docs, wikis, and project workspace',Airtable:'Database-driven project tracking',Smartsheet:'Spreadsheet-based work management',Teamwork:'Project management and time tracking',Wrike:'Project and work management',Podio:'Customizable work and project platform',Trello:'Kanban boards and visual tasks',Basecamp:'Simple project and team communication'}
  };
  const AUTH = {'Slack':'OAuth 2.0 · workspace install','Microsoft Teams':'OAuth 2.0 · Microsoft Graph','Google Drive':'OAuth 2.0 · Google scopes',GitHub:'OAuth 2.0 + PAT',Stripe:'API keys · secret + publishable',HubSpot:'OAuth 2.0 · private app','1Password':'OAuth 2.0 · 1Password Connect','Cloudflare Access':'API token · scoped',Vanta:'OAuth 2.0',Zoom:'Server-to-server OAuth'};
  const featuredSet = new Set(['Slack','Microsoft Teams','Google Drive','GitHub','HubSpot','Stripe','1Password','Cloudflare Access','Vanta','Zoom']);
  function initials(name){const p=name.split(' ').filter(Boolean);return p.length===1?p[0].slice(0,2).toUpperCase():(p[0][0]+p[1][0]).toUpperCase();}
  const allApps=[]; CATS.forEach(c=>{(USE[c.key]?Object.keys(USE[c.key]):[]).forEach(n=>{allApps.push({name:n,category:c.key,catLabel:c.label,use:USE[c.key][n],color:c.color,initials:initials(n),featured:featuredSet.has(n)});});});

  /* ============ STATE ============ */
  const connections = [];
  const connectedStores = new Set();
  const configuredFeeds = new Set();
  let typing;

  /* ============ HELPERS ============ */
  const $=(s,r=document)=>r.querySelector(s);
  const $$=(s,r=document)=>[...r.querySelectorAll(s)];
  function flash(msg){let b=$('#toast');if(!b){b=document.createElement('div');b.id='toast';document.body.appendChild(b);b.style.cssText='position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:var(--color-text);color:var(--color-bg);padding:10px 18px;border-radius:8px;font-size:13px;z-index:300;opacity:0;transition:opacity .2s;box-shadow:0 8px 24px rgba(0,0,0,.2)';}b.textContent=msg;b.style.opacity='1';clearTimeout(b._t);b._t=setTimeout(()=>b.style.opacity='0',2200);}
  const badge=(t,v='muted')=>`<span class="badge ${v}">${t}</span>`;
  const card=(head,body,o={})=>`<div class="card"${o.mb?' style="margin-bottom:var(--space-6)"':''}><div class="card-head"><h3>${head}</h3>${o.badge?`<span class="badge ${o.badge[1]}">${o.badge[0]}</span>`:''}</div><div class="card-body"${o.pt===false?' style="padding-top:0"':''}>${body}</div></div>`;
  const empty=(icon,title,sub,cta)=>`<div class="empty"><span class="empty-ico">${icon}</span><div class="empty-title">${title}</div><div class="empty-sub">${sub}</div>${cta?`<button class="btn btn-primary btn-sm" style="margin-top:var(--space-2)">${cta}</button>`:''}</div>`;
  const kpi=(l,v,d,ico,var2='')=>`<div class="kpi"><div class="kpi-top"><span class="kpi-label">${l}</span><span class="kpi-icon ${var2}">${ico}</span></div><div class="kpi-value">${v}</div><span class="kpi-delta">${d}</span></div>`;
  const welcome=(h1,p,actions)=>`<div class="welcome"><h1>${h1}</h1><p>${p}</p><div class="welcome-actions">${actions}</div></div>`;
  const sectionHead=(h2,sub,action='')=>`<div class="section-head"><div><h2>${h2}</h2><div class="sub">${sub}</div></div>${action}</div>`;
  const btn=(label,v='primary',ico='',sm=false,id='')=>`<button class="btn btn-${v} ${sm?'btn-sm':''}"${id?` id="${id}"`:''}>${ico}${label}</button>`;
  const tabs=(items)=>`<div class="tabs">${items.map((t,i)=>`<button class="tab${i===0?' active':''}" data-tab="${t[0]}">${t[1]}</button>`).join('')}</div>`;
  const panel=(id,html,active)=>`<div class="tab-panel${active?' active':''}" data-panel="${id}">${html}</div>`;
  const tableEmpty=(c,m)=>`<tr><td class="td cell-muted" colspan="${c}" style="text-align:center;padding:var(--space-8)">${m}</td></tr>`;

  /* ============ ROUTER ============ */
  const content = $('#content');
  function route(){
    const hash = location.hash.replace(/^#/,'') || '/';
    const parts = hash.split('/').filter(Boolean); // ['ws', id, module] or []
    closeDrawer();
    if(!parts.length){ renderDirectory(); return; }
    if(parts[0]==='ws' && parts[1]){
      const ws = WORKSPACES.find(w=>w.id===parts[1]);
      if(!ws){ renderDirectory(); return; }
      const mod = parts[2] || 'overview';
      if(!ws.modules.includes(mod) || !MODULE_DEFS[mod]){ location.hash='#/ws/'+ws.id+'/overview'; return; }
      renderWorkspace(ws, mod);
      return;
    }
    renderDirectory();
  }

  /* ============ DIRECTORY ============ */
  function renderDirectory(){
    const wsCards = WORKSPACES.map(w=>`
      <button class="ws-card" data-ws="${w.id}">
        <div class="ws-card-head"><span class="ws-card-mark" style="background:${w.color}">${w.short}</span>
          <div><div class="ws-card-name">${w.name}</div><div class="ws-card-role">${w.role}</div></div></div>
        <div class="ws-card-desc">${w.desc}</div>
        <div class="ws-card-stats">
          <div class="ws-card-stat"><div class="v">${w.modules.length}</div><div class="k">Modules</div></div>
          <div class="ws-card-stat"><div class="v">10+</div><div class="k">Services</div></div>
        </div>
        <span class="ws-card-open">Open dashboard ${I.arrow}</span>
      </button>`).join('');
    content.innerHTML = `
      <div class="directory-hero">
        <h1>Manage every service in one flow.</h1>
        <p>GEM Enterprise Workspace OS unifies cybersecurity, threat monitoring, real estate & legal services, and store management — each workspace is its own dedicated dashboard with scoped access, audit logging, and AI agents.</p>
      </div>
      <div class="section-head"><div><h2>Workspaces</h2><div class="sub">Choose a workspace to open its dedicated dashboard.</div></div></div>
      <div class="ws-grid">${wsCards}</div>`;
    $$('.ws-card').forEach(c=>c.addEventListener('click',()=>location.hash='#/ws/'+c.dataset.ws+'/overview'));
    setNav('','Workspace Directory');
    renderDirectorySidebar();
  }
  function renderDirectorySidebar(){
    const sidebar=$('#sidebar');
    sidebar.innerHTML=`
      <div class="brand"><svg class="brand-mark" viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="7" fill="currentColor"/><path d="M16 6l8 3v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V9l8-3z" fill="none" stroke="var(--color-accent)" stroke-width="2" stroke-linejoin="round"/></svg><div><div class="brand-name">GEM Enterprise</div><div class="brand-sub">Workspace OS</div></div></div>
      <nav class="nav-group" style="margin-top:var(--space-4)"><span class="nav-label">Organization</span><button class="nav-item active" data-ws-dir>${I.grid}Workspace Directory</button></nav>
      <div class="sidebar-foot"><span class="secure-pill"><span class="secure-dot"></span> Platform active</span></div>`;
    sidebar.querySelector('[data-ws-dir]').addEventListener('click',()=>location.hash='#/');
  }

  /* ============ SIDEBAR ============ */
  function renderSidebar(ws, activeMod){
    const sidebar = $('#sidebar');
    const inGroup = (g)=>ws.modules.filter(m=>GROUPS[g].includes(m));
    const groupHTML = (label, mods)=> mods.length ? `
      <span class="nav-label">${label}</span>
      ${mods.map(m=>`<button class="nav-item${m===activeMod?' active':''}" data-mod="${m}">${I[MODULE_DEFS[m].icon]}${MODULE_DEFS[m].label}</button>`).join('')}` : '';
    sidebar.innerHTML = `
      <div class="brand"><svg class="brand-mark" viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="7" fill="currentColor"/><path d="M16 6l8 3v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V9l8-3z" fill="none" stroke="var(--color-accent)" stroke-width="2" stroke-linejoin="round"/></svg><div><div class="brand-name">GEM Enterprise</div><div class="brand-sub">Workspace OS</div></div></div>
      <button class="ws-switch-back" id="wsBack">${I.chev.replace('M6 9l6 6 6-6','M15 18l-6-6 6-6')} All workspaces</button>
      <button class="ws-switch-card">
        <span class="workspace-avatar" style="background:${ws.color}">${ws.short}</span>
        <span class="workspace-meta"><span class="workspace-name">${ws.name}</span><span class="workspace-role">${ws.role}</span></span>
      </button>
      <nav class="nav-group" style="margin-top:var(--space-4)">
        ${groupHTML('Workspace', inGroup('primary'))}
        ${groupHTML('Platform', inGroup('platform'))}
        ${groupHTML('Governance', inGroup('governance'))}
      </nav>
      <div class="sidebar-foot"><span class="secure-pill"><span class="secure-dot"></span> Workspace active</span></div>`;
    $('#wsBack').addEventListener('click',()=>location.hash='#/');
    sidebar.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>location.hash='#/ws/'+ws.id+'/'+b.dataset.mod));
    if(window.innerWidth<820) sidebar.classList.add('open');
  }
  function setNav(crumb,title){ $('#crumbs').textContent=crumb; $('#pageTitle').textContent=title; }

  function renderWorkspace(ws, mod){
    renderSidebar(ws, mod);
    setNav(ws.name, MODULE_DEFS[mod].label);
    let html='';
    switch(mod){
      case 'overview': html=renderOverview(ws); break;
      case 'threats': html=renderThreats(ws); break;
      case 'cyber': html=renderCyber(ws); break;
      case 'realestate': html=renderRealEstate(ws); break;
      case 'stores': html=renderStores(ws); break;
      case 'plans': html=renderPlans(ws); break;
      case 'clients': html=renderClients(ws); break;
      case 'prod': html=renderProd(ws); break;
      case 'marketing': html=renderMarketing(ws); break;
      case 'sales': html=renderSales(ws); break;
      case 'ai': html=renderAI(ws); break;
      case 'integrations': html=renderIntegrations(ws); break;
      case 'community': html=renderCommunity(ws); break;
      case 'security': html=renderSecurity(ws); break;
      case 'settings': html=renderSettings(ws); break;
      default: html=renderOverview(ws);
    }
    content.innerHTML = html;
    content.scrollTop=0;
    bindView(ws, mod);
  }

  /* ============ MODULE: OVERVIEW ============ */
  function renderOverview(ws){
    return welcome(`Welcome to ${ws.name}`, ws.desc, btn('Create Workspace','primary',I.plus)+btn('Open Threat Monitoring','outline',I.radar)+btn('Connect an App','outline',I.link))
    + `<div class="kpi-grid">`
      + kpi('Integration Catalog', allApps.length, 'across 14 categories', I.link)
      + kpi('Workspace Modules', ws.modules.length, 'active modules', I.grid,'accent')
      + kpi('Automation Templates','24','ready to activate', I.bolt,'info')
      + kpi('Threat Feeds','9','available to configure', I.radar,'purple')
    + `</div>`
    + `<div class="grid-2">`
      + card('Platform Activity','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="activity">'
        + `<div class="activity-item"><span class="activity-dot accent"></span><div class="activity-body"><div class="activity-text">Workspace <strong>${ws.name}</strong> opened.</div><div class="activity-time">Just now · ${ws.role}</div></div></div>`
        + `<div class="activity-item"><span class="activity-dot"></span><div class="activity-body"><div class="activity-text"><strong>GEM Sentinel</strong> monitoring service available. Configure threat-intel feeds to activate.</div><div class="activity-time">1 hour ago</div></div></div>`
        + `<div class="activity-item"><span class="activity-dot muted"></span><div class="activity-body"><div class="activity-text">Automation template <strong>Client Onboarding Flow</strong> published.</div><div class="activity-time">Yesterday</div></div></div>`
        + `</div></div>`)
      + `<div class="stack">`
        + card('Quick Actions','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="qa-grid">'
          + `<button class="qa" data-jump="threats"><span class="qa-ico">${I.radar}</span><div><div class="qa-text">Threat Monitoring</div><div class="qa-sub">Configure Sentinel</div></div></button>`
          + `<button class="qa" data-jump="stores"><span class="qa-ico">${I.store}</span><div><div class="qa-text">Manage Stores</div><div class="qa-sub">Connect storefronts</div></div></button>`
          + `<button class="qa" data-jump="ai"><span class="qa-ico">${I.spark}</span><div><div class="qa-text">Configure AI</div><div class="qa-sub">Set up agents</div></div></button>`
          + `<button class="qa" data-jump="integrations"><span class="qa-ico">${I.link}</span><div><div class="qa-text">Connect App</div><div class="qa-sub">Browse catalog</div></div></button>`
          + `</div></div>`)
        + card('Services in this workspace','',{}).replace('<div class="card-body"></div>','<div class="card-body">'+ws.modules.filter(m=>m!=='overview').map(m=>`<div class="stat-line"><span>${MODULE_DEFS[m].label}</span><span class="v">${m==='threats'?'Ready to configure':'Enabled'}</span></div>`).join('')+'</div>')
      + `</div>`
    + `</div>`;
  }

  /* ============ MODULE: THREAT & MONITORING ============ */
  function renderThreats(ws){
    const surfaceCards = SURFACES.map(s=>`<div class="surface-card"><span class="surface-ico">${I[s.icon]}</span><div class="surface-name">${s.name}</div><div class="surface-status">${s.use}</div><span class="badge muted">Not configured</span></div>`).join('');
    const feedCards = FEEDS.map((f,i)=>`<div class="feed-card"><div class="feed-name">${f.name}</div><div class="feed-desc">${f.desc}</div><div class="feed-foot"><span class="badge muted">${f.cat}</span><button class="btn-link btn-sm feed-config" data-feed="${i}">Configure</button></div></div>`).join('');
    const pbList = PLAYBOOKS.map(p=>`<div class="pb-item"><span class="pb-ico">${I.bolt}</span><div class="meta" style="flex:1"><div class="pb-name">${p.name}</div><div class="pb-stages">${p.stages.map(s=>`<span class="pb-stage">${s}</span>`).join('')}</div></div><span class="badge muted">Template</span></div>`).join('');
    const traceSteps=[['01','Ingest'],['02','Normalize'],['03','Enrich'],['04','Score'],['05','Route'],['06','Alert'],['07','Contain'],['08','Close']];
    const traceHTML = `<div class="trace-pipe">${traceSteps.map((s,i)=>`<div class="trace-node"><div class="step">${s[0]}</div><div class="label">${s[1]}</div></div>${i<traceSteps.length-1?`<div class="trace-arrow">${I.arrow}</div>`:''}`).join('')}</div>`;
    const feedCount = configuredFeeds.size;
    return `
    <div class="threat-hero">
      <span class="sentinel-mark">${I.radar}</span>
      <div style="flex:1;min-width:240px"><h2 style="font-size:var(--text-xl);font-weight:600">GEM Sentinel — Threat & Monitoring</h2>
      <p style="font-size:var(--text-sm);color:var(--color-text-muted);margin-top:var(--space-1)">Configurable monitoring service detecting malware, phishing, scams, and fraud across email, URLs, files, identity, payments, stores, and domains. Connect threat-intel feeds and authorized connectors to activate live detection.</p></div>
      <div style="text-align:right"><div style="font-family:var(--font-display);font-size:var(--text-xl);font-weight:600">${feedCount}/9</div><div style="font-size:var(--text-xs);color:var(--color-text-muted)">feeds configured</div></div>
    </div>
    <div class="kpi-grid">`
      + kpi('Live Alerts','0','until feeds connected', I.bell,'accent')
      + kpi('SOAR Playbooks','8','ready to activate', I.bolt,'info')
      + kpi('Intel Feeds', FEEDS.length, feedCount+' configured', I.radar,'purple')
      + kpi('Response SLA','Configurable','auto-route ready', I.shield)
    + `</div>`
    + tabs([['cmd','Command Center'],['inbox','Alert Inbox'],['trace','Flow Trace'],['feeds','Intel Feeds'],['pb','SOAR Playbooks'],['bot','Bot Settings']])
    + panel('cmd', `<div class="kpi-grid" style="grid-template-columns:repeat(auto-fill,minmax(180px,1fr))">${surfaceCards}</div>`, true)
    + panel('inbox', card('Alert Inbox','',{}).replace('<div class="card-body"></div>','<div class="card-body" style="padding-top:0"><div class="table-wrap"><table><thead><tr><th class="th">Severity</th><th class="th">Threat type</th><th class="th">Source</th><th class="th">Confidence</th><th class="th">Status</th><th class="th">SLA</th></tr></thead><tbody>'+tableEmpty(6,'No live threat signals connected yet. Configure a threat-intel feed to begin ingesting alerts.')+'</tbody></table></div></div>'))
    + panel('trace', `<div class="card"><div class="card-head"><h3>Flow Trace</h3></div><div class="card-body"><p style="font-size:var(--text-sm);color:var(--color-text-muted);margin-bottom:var(--space-5)">Every alert is traced through the full detection-and-response pipeline. Select an alert in the inbox to view its end-to-end trace.</p>${traceHTML}<div style="margin-top:var(--space-5)">${empty(I.eye,'No alert selected','Select an alert in the inbox to view the full flow trace — from ingestion through enrichment, scoring, routing, and closure.')}</div></div></div>`)
    + panel('feeds', `<div class="feed-grid">${feedCards}</div>`)
    + panel('pb', `<div class="card"><div class="card-head"><h3>SOAR Playbooks</h3>${badge('8 templates','info')}</div><div class="card-body" style="padding-top:0">${pbList}</div></div>`)
    + panel('bot', `<div class="grid-2-eq">`
      + card('Detection Settings','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="range-row"><label style="font-size:var(--text-sm);min-width:160px">Confidence threshold</label><input type="range" class="range" min="0" max="100" value="70" id="confRange"><span class="range-val" id="confVal">70</span></div><div class="stat-line"><span>Auto-route qualified alerts</span><span class="switch on" role="switch"></span></div><div class="stat-line"><span>Human approval before containment</span><span class="switch on" role="switch"></span></div><div class="stat-line"><span>Sandbox detonation</span><span class="switch" role="switch"></span></div></div>')
      + card('Evidence & Escalation','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="stat-line"><span>Evidence retention</span><select class="select" style="width:auto"><option>90 days</option><option>1 year</option><option>2 years</option></select></div><div class="stat-line"><span>Escalation channel</span><select class="select" style="width:auto"><option>Slack</option><option>Microsoft Teams</option><option>Email</option></select></div><div class="stat-line"><span>Notify on critical</span><span class="switch on" role="switch"></span></div><div class="stat-line"><span>Digest summary</span><span class="switch" role="switch"></span></div></div>')
    + `</div>`);
  }

  /* ============ MODULE: CYBERSECURITY ============ */
  function renderCyber(ws){
    const lanes = [
      {n:'Vulnerability Assessment',d:'Identify and prioritize exposed assets and CVEs.'},{n:'Phishing Defense',d:'Inbound email analysis, URL detonation, and takedown.'},
      {n:'Malware Response',d:'File hash analysis, sandboxing, and containment.'},{n:'Identity & Access Review',d:'RBAC review, MFA posture, and ATO detection.'},
      {n:'Compliance Controls',d:'Policy, audit logging, and control evidence.'},{n:'Incident Response',d:'Triage, containment, eradication, and recovery.'},
      {n:'Security Awareness',d:'Training modules and simulated phishing.'},{n:'Evidence Vault',d:'Chain-of-custody storage for incidents.'}
    ];
    return sectionHead('Cybersecurity Services','Enterprise-grade security lanes covering assessment, defense, response, and compliance.')
    + `<div class="lane-grid">${lanes.map(l=>`<div class="lane-card"><span class="lane-ico">${I.shield}</span><h4>${l.n}</h4><p>${l.d}</p><div class="lane-foot"><span class="badge muted">Available</span><button class="btn-link btn-sm">Configure</button></div></div>`).join('')}</div>`
    + `<div class="card" style="margin-top:var(--space-6)"><div class="card-body"><div class="notice">${I.radar}<div>Security lanes integrate with GEM Sentinel. Configure monitoring feeds in the Threat &amp; Monitoring module to enable live detection across these services.</div></div></div></div>`;
  }

  /* ============ MODULE: REAL ESTATE & LEGAL ============ */
  function renderRealEstate(ws){
    const matters = [['Property risk review','In review'],['Due diligence checklist','Not started'],['Contract & document review','Pending approval'],['Title & wire-fraud watch','Monitoring'],['Legal matter tracking','Open'],['Deadlines & obligations','Upcoming']];
    return sectionHead('Real Estate & Legal Services','Property risk, due diligence, contract review, and legal matter workflows — including title and wire-fraud watch.')
    + `<div class="tabs"><button class="tab active" data-tab="re-matters">Matters</button><button class="tab" data-tab="re-dd">Due Diligence</button><button class="tab" data-tab="re-fraud">Wire-Fraud Watch</button></div>`
    + panel('re-matters', `<div class="card"><div class="card-body" style="padding-top:0"><div class="table-wrap"><table><thead><tr><th class="th">Matter</th><th class="th">Stage</th><th class="th">Owner</th><th class="th">Updated</th></tr></thead><tbody>${matters.map(m=>`<tr><td class="td cell-strong">${m[0]}</td><td class="td">${badge(m[1], m[1]==='Monitoring'||m[1]==='In review'?'info':'warning')}</td><td class="td cell-muted">—</td><td class="td cell-id">—</td></tr>`).join('')}</tbody></table></div></div></div>`, true)
    + panel('re-dd', `<div class="card"><div class="card-body"><div class="task"><button class="checkbox checked"></button><div class="task-text">Ownership & title verification</div></div><div class="task"><button class="checkbox checked"></button><div class="task-text">Lien & encumbrance search</div></div><div class="task"><button class="checkbox"></button><div class="task-text">Zoning & permit review</div></div><div class="task"><button class="checkbox"></button><div class="task-text">Environmental screening</div></div><div class="task"><button class="checkbox"></button><div class="task-text">Contract redline & approval</div></div></div></div>`)
    + panel('re-fraud', `<div class="card"><div class="card-body">${empty(I.lock,'Wire-fraud monitoring active','GEM Sentinel watches for wire-instruction tampering, domain spoofing, and sender-impersonation signals tied to active matters. Connect identity feeds to enable live detection.')}</div></div>`);
  }

  /* ============ MODULE: STORE MANAGEMENT ============ */
  function renderStores(ws){
    const storeCards = STORES.map((s,i)=>`<button class="store-card store-conn" data-store="${i}"><div class="store-card-top"><span class="store-icon" style="background:${s.color}">${initials(s.name)}</span><div><div class="store-name">${s.name}</div><div class="store-sub">${s.desc}</div></div></div><div class="store-foot"><span class="badge muted">Connect</span></div></button>`).join('');
    const connCount = connectedStores.size;
    return sectionHead('Store Management','Manage stores, orders, products, reviews, payouts, and fraud checks across marketplaces.', btn('Refresh','ghost',I.radar,'sm'))
    + `<div class="kpi-grid">`
      + kpi('Connected Stores', connCount, 'of '+STORES.length, I.store)
      + kpi('Marketplaces', STORES.length, 'available', I.cart,'accent')
      + kpi('Fraud Checks','Ready','per-order scoring', I.shield,'info')
      + kpi('Policy Alerts','0','until synced', I.flag,'purple')
    + `</div>`
    + `<div class="tabs"><button class="tab active" data-tab="st-stores">Store Directory</button><button class="tab" data-tab="st-orders">Orders</button><button class="tab" data-tab="st-fraud">Fraud Checks</button></div>`
    + panel('st-stores', `<div class="store-grid">${storeCards}</div>`, true)
    + panel('st-orders', card('Orders','',{}).replace('<div class="card-body"></div>','<div class="card-body" style="padding-top:0"><div class="table-wrap"><table><thead><tr><th class="th">Order</th><th class="th">Store</th><th class="th">Total</th><th class="th">Status</th></tr></thead><tbody>'+tableEmpty(4, connCount?'No orders synced in this period.':'Connect a store to sync orders.')+'</tbody></table></div></div>'))
    + panel('st-fraud', card('Fraud Checks','Per-order fraud scoring runs on connected stores.',{}).replace('<div class="card-body"></div>','<div class="card-body" style="padding-top:0"><div class="table-wrap"><table><thead><tr><th class="th">Signal</th><th class="th">Description</th><th class="th">Status</th></tr></thead><tbody>'+[['Impersonation','Seller or listing impersonation'],['Payment fraud','Chargeback & velocity signals'],['Scam listings','Too-good pricing & new accounts'],['Policy violation','Prohibited or counterfeit items']].map(r=>`<tr><td class="td cell-strong">${r[0]}</td><td class="td cell-muted">${r[1]}</td><td class="td">${badge('Ready','muted')}</td></tr>`).join('')+'</tbody></table></div></div>'));
  }

  /* ============ MODULE: PROTECTION PLANS (Family) ============ */
  function renderPlans(ws){
    const plans=[['GEM Family Protection','$9.99','Monthly','Active'],['GEM Business Monitor','$49','Monthly','Available'],['GEM Enterprise Shield','$799','Annual','Available']];
    return sectionHead('Protection Plans','Member plans and subscription operations for the Family Protection workspace.')
    + `<div class="grid-3">${plans.map(p=>`<div class="card"><div class="card-body"><div style="display:flex;align-items:baseline;gap:8px"><span style="font-family:var(--font-display);font-size:var(--text-xl);font-weight:600">${p[1]}</span><span style="font-size:var(--text-xs);color:var(--color-text-muted)">/ ${p[2]}</span></div><div style="font-size:var(--text-sm);font-weight:600;margin-top:var(--space-2)">${p[0]}</div><div style="margin-top:var(--space-3)">${badge(p[3], p[3]==='Active'?'success':'muted')}</div><button class="btn btn-ghost btn-sm" style="margin-top:var(--space-4);width:100%">Manage</button></div></div>`).join('')}</div>`;
  }

  /* ============ MODULE: WORKSPACES & CLIENTS ============ */
  function renderClients(ws){
    return sectionHead('Workspaces & Clients','Provision and manage client tenants, administrators, and role hierarchy.', btn('Create Workspace','primary',I.plus))
    + `<div class="card" style="margin-bottom:var(--space-6)"><div class="card-body">${empty(I.users,'No client workspaces provisioned yet','Create a workspace to onboard a client, assign administrators, and activate services. Each tenant is isolated with scoped permissions.','Create first workspace')}</div></div>`
    + `<div class="grid-2-eq">`
      + card('Role Hierarchy','',{}).replace('<div class="card-body"></div>','<div class="card-body">'+[['Super Admin','Full organization control','accent','Org-level'],['Workspace Admin','Manages a client tenant and its team','info','Per-tenant'],['Client Admin','Client-side administrator','muted','Client-side'],['Member','Staff or client user with scoped access','muted','Scoped']].map(r=>`<div class="row"><span class="ava lg">${r[0].split(' ').map(w=>w[0]).join('').slice(0,2)}</span><div class="meta"><div class="title">${r[0]}</div><div class="sub">${r[1]}</div></div>${badge(r[3],r[2])}</div>`).join('')+'</div>')
      + card('Invite Administrator','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div style="display:flex;flex-direction:column;gap:var(--space-3)"><input type="email" class="input" placeholder="admin@example.com" /><select class="select"><option>Workspace Admin</option><option>Client Admin</option><option>Member</option></select>'+btn('Send Invitation','primary')+`</div></div>`)
    + `</div>`;
  }

  /* ============ MODULE: PRODUCTION & DEV ============ */
  function renderProd(ws){
    const envs=[['Production','success','Live','v2.4.1','99.98%','us-east-1','2h ago'],['Staging','warning','In Review','v2.5.0-rc1','Passing','us-east-1','Approval'],['Development','muted','Active','main','4 open PRs','eu-west-1','Healthy']];
    return sectionHead('Production & Development','Environments, deployments, releases, and incident queues.', btn('New Deployment','primary',I.plus))
    + `<div class="env-grid">${envs.map(e=>`<div class="env-card"><div class="env-head"><div class="env-name"><span class="env-dot" style="background:var(--color-${e[1]==='success'?'success':e[1]==='warning'?'accent':'text-faint'})"></span>${e[0]}</div>${badge(e[2],e[1])}</div><div class="env-body"><div class="env-row"><span class="k">Version</span><span class="v">${e[3]}</span></div><div class="env-row"><span class="k">${e[0]==='Production'?'Uptime':'Build'}</span><span class="v">${e[4]}</span></div><div class="env-row"><span class="k">Region</span><span class="v">${e[5]}</span></div><div class="env-row"><span class="k">Last deploy</span><span class="v">${e[6]}</span></div></div></div>`).join('')}</div>`
    + `<div class="grid-2" style="margin-top:var(--space-6)">`
      + card('Deployment Pipeline','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="pipeline"><div class="pipe-step"><span class="pipe-node done">✓</span><span class="pipe-label">Build</span></div><span class="pipe-line done"></span><div class="pipe-step"><span class="pipe-node done">✓</span><span class="pipe-label">Test</span></div><span class="pipe-line done"></span><div class="pipe-step"><span class="pipe-node done">✓</span><span class="pipe-label">Scan</span></div><span class="pipe-line done"></span><div class="pipe-step"><span class="pipe-node active">4</span><span class="pipe-label">Staging</span></div><span class="pipe-line"></span><div class="pipe-step"><span class="pipe-node">5</span><span class="pipe-label">Approve</span></div><span class="pipe-line"></span><div class="pipe-step"><span class="pipe-node">6</span><span class="pipe-label">Deploy</span></div></div><div style="margin-top:var(--space-5);display:flex;gap:var(--space-3)">'+btn('Promote to Production','primary','','sm')+btn('View Logs','ghost','','sm')+'</div></div>')
      + card('Incident Queue','3 open',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="task"><button class="checkbox"></button><div class="task-text">Investigate webhook delivery failures</div>'+badge('High','error')+'</div><div class="task"><button class="checkbox"></button><div class="task-text">Mobile viewport overlap on sidebar</div>'+badge('Medium','warning')+'</div><div class="task done"><button class="checkbox checked"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 13l4 4L19 7"/></svg></button><div class="task-text">Export naming fix</div>'+badge('Resolved','success')+'</div></div>')
    + `</div>`;
  }

  /* ============ MODULE: MARKETING ============ */
  function renderMarketing(ws){
    const channels=[['Email','Connect ESP'],['Social','Connect network'],['Web','Publish to site'],['Ads','Connect ad account']];
    return sectionHead('Marketing Studio','Campaigns, content, audiences, and AI-assisted copy across channels.', btn('New Campaign','primary',I.plus))
    + `<div class="kpi-grid">${kpi('Campaign Templates','18','email · social · web',I.chart)}${kpi('Audience Segments','6','configurable',I.users,'accent')}${kpi('Channels','4','ready to connect',I.bars,'info')}${kpi('AI Writer','Ready','configure sources',I.spark,'purple')}</div>`
    + `<div class="grid-2-eq"><div class="stack">`
      + card('Channels','4 available',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="grid-2">'+channels.map(c=>`<button class="qa" data-connect-channel="${c[0]}"><span class="qa-ico">${c[0]==='Email'?I.mail:c[0]==='Web'?I.doc:c[0]==='Ads'?I.bolt:I.users}</span><div><div class="qa-text">${c[0]}</div><div class="qa-sub">${c[1]}</div></div></button>`).join('')+'</div></div>')
      + card('Content Calendar','No scheduled posts',{}).replace('<div class="card-body"></div>','<div class="card-body" style="padding-top:0"><div class="table-wrap"><table><thead><tr><th class="th">Title</th><th class="th">Channel</th><th class="th">Status</th><th class="th">Date</th></tr></thead><tbody>'+tableEmpty(4,'Schedule your first post to populate the calendar.')+'</tbody></table></div></div>')
    + `</div>`
      + card('AI Campaign Writer','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div style="display:flex;gap:var(--space-2);margin-bottom:var(--space-3)"><button class="btn btn-ghost btn-sm ai-gen-tab active" data-gen="email">Email</button><button class="btn btn-ghost btn-sm ai-gen-tab" data-gen="social">Social</button><button class="btn btn-ghost btn-sm ai-gen-tab" data-gen="ad">Ad</button></div><div class="ai-output" id="aiGenOut"><span class="typing">Select a format and generate a draft. The AI writer produces content you review before publishing.</span></div><div style="display:flex;gap:var(--space-3);margin-top:var(--space-3)">'+btn('Generate','accent',I.spark,'sm','aiGenBtn')+btn('Review & Insert','ghost','','sm')+'</div></div>')
    + `</div></div>`;
  }

  /* ============ MODULE: SALES CRM ============ */
  function renderSales(ws){
    return sectionHead('Sales CRM','Pipeline, proposals, follow-ups, and forecasting.', btn('Add Deal','primary',I.plus))
    + `<div class="card" style="margin-bottom:var(--space-6)"><div class="card-body">${empty(I.bars,'Connect a CRM to activate pipeline analytics','Link HubSpot, Salesforce, Pipedrive, or another CRM from the integration catalog to sync deals, leads, and forecasts here.','Browse CRM Integrations')}</div></div>`
    + `<div class="grid-2-eq">`
      + card('Sales Funnel','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="funnel"><div class="funnel-bar"><span class="funnel-label">Leads</span><div class="funnel-track"><div class="funnel-fill" style="width:100%"><span class="num">0</span></div></div></div><div class="funnel-bar"><span class="funnel-label">Qualified</span><div class="funnel-track"><div class="funnel-fill" style="width:0%"></div></div></div><div class="funnel-bar"><span class="funnel-label">Proposal</span><div class="funnel-track"><div class="funnel-fill" style="width:0%"></div></div></div><div class="funnel-bar"><span class="funnel-label">Won</span><div class="funnel-track"><div class="funnel-fill" style="width:0%"></div></div></div></div></div>')
      + card('Forecast','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="stat-line"><span>Quarter target</span><span class="v">—</span></div><div class="stat-line"><span>Pipeline value</span><span class="v">—</span></div><div class="stat-line"><span>Win rate</span><span class="v">—</span></div><div class="stat-line"><span>Avg. deal size</span><span class="v">—</span></div></div>')
    + `</div>`
    + `<div class="card" style="margin-top:var(--space-6)"><div class="card-head"><h3>Open Deals</h3>${badge('Sync from CRM','muted')}</div><div class="card-body" style="padding-top:0"><div class="table-wrap"><table><thead><tr><th class="th">Deal</th><th class="th">Company</th><th class="th">Stage</th><th class="th">Value</th><th class="th">Owner</th></tr></thead><tbody>${tableEmpty(5,'Connect a CRM to sync leads and open deals here.')}</tbody></table></div></div></div>`;
  }

  /* ============ MODULE: AI SERVICES ============ */
  function renderAI(ws){
    const agents=[['Security Analyst',I.shield,'Exposure monitoring, advisory flagging, briefing drafts.'],['Sales Assistant',I.bars,'Lead qualification, proposal drafts, follow-ups.'],['Marketing Writer',I.chart,'Email, social, and ad copy generation.'],['Community Moderator',I.users,'Post review, FAQ answers, escalation.'],['Compliance Reviewer',I.lock,'Eligibility, scope, jurisdiction, and provider checks.']];
    return sectionHead('AI Services','Configure AI agents, prompt templates, knowledge sources, and run live tasks.', btn('New Agent','accent',I.plus))
    + `<div class="kpi-grid">${kpi('Available Agents','5','role-based templates',I.spark)}${kpi('Prompt Templates','24','configurable',I.doc,'accent')}${kpi('Knowledge Sources','0','connect to enable',I.db,'info')}${kpi('Guardrails','On','permission-scoped',I.lock,'purple')}</div>`
    + `<div class="grid-2">`
      + card('AI Agents','5 templates',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="agent-grid">'+agents.map(a=>`<div class="agent-card"><span class="agent-ico">${a[1]}</span><h4>${a[0]}</h4><div class="agent-desc">${a[2]}</div><span class="badge muted">Not configured</span></div>`).join('')+'</div></div>')
      + card('AI Console','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div style="font-size:var(--text-xs);color:var(--color-text-muted);margin-bottom:var(--space-2)">Run a task with the Compliance Reviewer</div><div class="ai-output" id="aiConsoleOut"><span class="typing">Configure a knowledge source, then run a compliance review to generate a structured briefing.</span></div><div style="display:flex;gap:var(--space-3);margin-top:var(--space-3)">'+btn('Run Task','accent',I.spark,'sm','aiConsoleBtn')+btn('Save Output','ghost','','sm')+'</div></div>')
    + `</div>`
    + `<div class="card" style="margin-top:var(--space-6)"><div class="card-body"><div class="notice">${I.lock}<div>Agents operate only within permissions you define. Every action is logged and traceable through the audit system.</div></div></div></div>`;
  }

  /* ============ MODULE: INTEGRATIONS ============ */
  function renderIntegrations(ws){
    return sectionHead('Automations & Integrations','Browse the integration catalog, build automation flows, and manage API access.')
    + `<div class="tabs"><button class="tab active" data-tab="apps">Integration Catalog</button><button class="tab" data-tab="conn">My Connections <span class="count" id="connBadge" style="margin-left:4px">${connections.length}</span></button><button class="tab" data-tab="flows">Automation Builder</button><button class="tab" data-tab="keys">API & Webhooks</button></div>`
    + panel('apps', `<div class="catalog-toolbar"><div class="catalog-search">${I.search}<input type="search" id="appSearch" placeholder="Search 196 integrations by name or use case…" /></div><div class="chips" id="catChips"></div></div><div class="card" style="margin-bottom:var(--space-6)"><div class="card-head"><h3>Featured for GEM</h3><span class="sub">Recommended for cybersecurity & compliance operations</span></div><div class="card-body"><div class="market-grid" id="featuredGrid"></div></div></div><div class="card"><div class="card-head"><h3>All Integrations</h3><span class="sub" id="resultCount">—</span></div><div class="card-body"><div class="market-grid" id="appGrid"></div></div></div>`, true)
    + panel('conn', `<div class="card"><div class="empty" id="connEmpty">${empty(I.link,'No connected integrations yet','Apps you authorize appear here with sync status, authentication method, scopes, and last-sync time.','')}</div><div class="table-wrap" id="connList" style="display:none"></div></div>`)
    + panel('flows', card('Automation Builder','Client Onboarding Flow',{badge:['Active','info']}).replace('<div class="card-body"></div>','<div class="card-body"><div class="flow"><div class="flow-step"><span class="flow-num">1</span><div class="flow-card"><div class="flow-title">Trigger: Intake form submitted</div><div class="flow-sub">Source: Website kickoff form</div></div></div><div class="flow-conn"></div><div class="flow-step"><span class="flow-num">2</span><div class="flow-card"><div class="flow-title">AI: Qualify and score lead</div><div class="flow-sub">Agent: Sales Assistant</div></div></div><div class="flow-conn"></div><div class="flow-step"><span class="flow-num">3</span><div class="flow-card"><div class="flow-title">Action: Create workspace & onboarding tasks</div><div class="flow-sub">Provisions client tenant and checklist</div></div></div><div class="flow-conn"></div><div class="flow-step"><span class="flow-num">4</span><div class="flow-card"><div class="flow-title">Notify: Administrator</div><div class="flow-sub">Channel: Slack or Microsoft Teams</div></div></div><div class="flow-conn"></div><div class="flow-step"><span class="flow-num">5</span><div class="flow-card"><div class="flow-title">AI: Draft welcome message</div><div class="flow-sub">Agent: Marketing Writer · awaits approval</div></div></div></div><div style="display:flex;gap:var(--space-3);margin-top:var(--space-5)">'+btn('Activate Flow','primary','','sm')+btn('Add Step','ghost','','sm')+btn('Test Run','ghost','','sm')+'</div></div>'))
    + panel('keys', `<div class="grid-2-eq">`+card('API Keys','',{}).replace('<div class="card-body"></div>','<div class="card-body" style="padding-top:0"><div class="table-wrap"><table><thead><tr><th class="th">Label</th><th class="th">Key</th><th class="th">Created</th></tr></thead><tbody><tr><td class="td cell-strong">Production</td><td class="td cell-id">gem_pk_••••8421</td><td class="td cell-muted">Aug 01</td></tr><tr><td class="td cell-strong">Webhook ingest</td><td class="td cell-id">gem_wh_••••0a3f</td><td class="td cell-muted">Jul 22</td></tr><tr><td class="td cell-strong">Read-only analytics</td><td class="td cell-id">gem_ro_••••91bc</td><td class="td cell-muted">Jun 10</td></tr></tbody></table></div><div style="padding:var(--space-4) 0 0">'+btn('Generate Key','primary','','sm')+'</div></div>')+card('Webhooks','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="stat-line"><span>Endpoint</span><span class="v" style="font-size:var(--text-xs)">hooks.gem…/v1</span></div><div class="stat-line"><span>Events delivered (24h)</span><span class="v">2,418</span></div><div class="stat-line"><span>Failed</span><span class="v">3</span></div><div class="stat-line"><span>Retry policy</span><span class="v">Exponential</span></div></div>')+`</div>`);
  }

  /* ============ MODULE: COMMUNITY ============ */
  function renderCommunity(ws){
    return sectionHead('Community','Members, groups, announcements, events, and courses.', btn('New Announcement','primary',I.plus))
    + `<div class="card" style="margin-bottom:var(--space-6)"><div class="card-body">${empty(I.users,'Community not yet enabled','Enable the community module to create groups, publish announcements, and host member resources.','Enable Community')}</div></div>`
    + `<div class="tabs"><button class="tab active" data-tab="c-groups">Groups</button><button class="tab" data-tab="c-news">Announcements</button><button class="tab" data-tab="c-events">Events</button><button class="tab" data-tab="c-courses">Courses</button></div>`
    + panel('c-groups', `<div class="card"><div class="card-body">${empty(I.users,'No groups created','Create member groups to organize discussions, announcements, and resources by audience or topic.','Create Group')}</div></div>`, true)
    + panel('c-news', `<div class="card"><div class="card-body" style="padding-top:0"><div class="table-wrap"><table><thead><tr><th class="th">Title</th><th class="th">Audience</th><th class="th">Status</th><th class="th">Posted</th></tr></thead><tbody>${tableEmpty(4,'No announcements published yet.')}</tbody></table></div></div></div>`)
    + panel('c-events', `<div class="card"><div class="card-body">${empty(I.grid,'No upcoming events','Schedule webinars, workshops, or Q&A sessions for your community.','Schedule Event')}</div></div>`)
    + panel('c-courses', `<div class="card"><div class="card-body">${empty(I.doc,'No courses published','Build courses and learning paths for members. Progress and completion are tracked per member.','Create Course')}</div></div>`);
  }

  /* ============ MODULE: SECURITY & COMPLIANCE ============ */
  function renderSecurity(ws){
    return sectionHead('Security & Compliance','Access control, audit logging, policies, and eligibility gates.')
    + `<div class="grid-2-eq">`
      + card('Role-Based Access Matrix','',{}).replace('<div class="card-body"></div>','<div class="card-body" style="padding-top:0"><div class="table-wrap"><table><thead><tr><th class="th">Capability</th><th class="th">Super</th><th class="th">WS Admin</th><th class="th">Client</th><th class="th">Member</th></tr></thead><tbody>'+[['Manage workspaces','✓','—','—','—'],['Invite administrators','✓','✓','—','—'],['View tenant data','✓','✓','✓','scoped'],['Approve workflows','✓','✓','✓','—'],['Audit log access','✓','read','—','—']].map(r=>`<tr><td class="td cell-strong">${r[0]}</td><td class="td" style="text-align:center;color:var(--color-${r[1]==='✓'?'success':'text-faint'})">${r[1]==='✓'?'✓':r[1]==='—'?'—':r[1]}</td><td class="td" style="text-align:center;color:var(--color-${r[2]==='✓'?'success':'text-faint'})">${r[2]}</td><td class="td" style="text-align:center;color:var(--color-${r[3]==='✓'?'success':'text-faint'})">${r[3]}</td><td class="td" style="text-align:center;color:var(--color-text-faint)">${r[4]}</td></tr>`).join('')+'</tbody></table></div></div>')
      + card('Eligibility Gates','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="task done"><button class="checkbox checked"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 13l4 4L19 7"/></svg></button><div class="task-text" style="font-size:var(--text-xs)">Eligibility check</div></div><div class="task done"><button class="checkbox checked"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 13l4 4L19 7"/></svg></button><div class="task-text" style="font-size:var(--text-xs)">Scope & provider verification</div></div><div class="task done"><button class="checkbox checked"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 13l4 4L19 7"/></svg></button><div class="task-text" style="font-size:var(--text-xs)">Jurisdiction check</div></div><div class="task"><button class="checkbox"></button><div class="task-text" style="font-size:var(--text-xs)">Contractual review</div></div></div>')
    + `</div>`
    + `<div class="grid-3" style="margin-top:var(--space-6)">`
      + card('Access Policies','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="row" style="border:none;padding:var(--space-2) 0"><span style="font-size:var(--text-sm)">Two-factor auth</span><span class="switch on" role="switch"></span></div><div class="row" style="border:none;padding:var(--space-2) 0"><span style="font-size:var(--text-sm)">SSO-ready</span><span class="switch on" role="switch"></span></div><div class="row" style="border:none;padding:var(--space-2) 0"><span style="font-size:var(--text-sm)">Session timeout</span><span class="switch on" role="switch"></span></div><div class="row" style="border:none;padding:var(--space-2) 0"><span style="font-size:var(--text-sm)">IP allowlist</span><span class="switch" role="switch"></span></div></div>')
      + card('Compliance Controls','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="stat-line"><span>RBAC</span><span class="v">'+badge('Active','success')+'</span></div><div class="stat-line"><span>Audit logging</span><span class="v">'+badge('Active','success')+'</span></div><div class="stat-line"><span>Data encryption</span><span class="v">'+badge('Configured','success')+'</span></div><div class="stat-line"><span>2FA / SSO</span><span class="v">'+badge('Ready','success')+'</span></div></div>')
      + card('Recent Audit','',{}).replace('<div class="card-body"></div>','<div class="card-body" style="padding-top:0"><div class="table-wrap"><table><thead><tr><th class="th">Actor</th><th class="th">Action</th><th class="th">Time</th></tr></thead><tbody><tr><td class="td cell-strong">Super Admin</td><td class="td cell-muted">Created workspace</td><td class="td cell-id">1h ago</td></tr><tr><td class="td cell-strong">Workspace Admin</td><td class="td cell-muted">Invited member</td><td class="td cell-id">1d ago</td></tr><tr><td class="td cell-strong">System</td><td class="td cell-muted">Config updated</td><td class="td cell-id">2d ago</td></tr></tbody></table></div></div>')
    + `</div>`;
  }

  /* ============ MODULE: SETTINGS & BILLING ============ */
  function renderSettings(ws){
    return sectionHead('Settings & Billing','Branding, plan, team, and notification preferences.')
    + `<div class="grid-2-eq">`
      + card('Branding & Domain','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div style="display:flex;flex-direction:column;gap:var(--space-3)"><label style="font-size:var(--text-xs);color:var(--color-text-muted)">Portal URL</label><input class="input" value="portal.gemcybersecurityassist.com" /><label style="font-size:var(--text-xs);color:var(--color-text-muted)">Brand name</label><input class="input" value="GEM Enterprise" /><div style="display:flex;align-items:center;gap:var(--space-2);margin-top:var(--space-2)"><span class="switch on" role="switch"></span><span style="font-size:var(--text-sm)">White-label client portal</span></div>'+btn('Save Branding','primary','','sm')+'</div></div>')
      + card('Plan','Pinnacle',{}).replace('<div class="card-body"></div>','<div class="card-body"><div style="display:flex;align-items:baseline;gap:var(--space-2);margin-bottom:var(--space-3)"><span style="font-family:var(--font-display);font-size:var(--text-xl);font-weight:600">$99</span><span style="font-size:var(--text-sm);color:var(--color-text-muted)">/ month · unlimited users</span></div><div class="stat-line"><span>Workspaces</span><span class="v">Unlimited</span></div><div class="stat-line"><span>Storage</span><span class="v">Included</span></div><div class="stat-line"><span>AI runs</span><span class="v">50K / mo</span></div><div style="margin-top:var(--space-4)">'+btn('Manage Plan','ghost','','sm')+'</div></div>')
    + `</div>`
    + `<div class="grid-3" style="margin-top:var(--space-6)">`
      + card('Team','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="stat-line"><span>Super Admins</span><span class="v">1</span></div><div class="stat-line"><span>Workspace Admins</span><span class="v">0</span></div><div class="stat-line"><span>Total members</span><span class="v">1</span></div></div>')
      + card('Notifications','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="row" style="border:none;padding:var(--space-2) 0"><span style="font-size:var(--text-sm)">Workspace alerts</span><span class="switch on"></span></div><div class="row" style="border:none;padding:var(--space-2) 0"><span style="font-size:var(--text-sm)">AI activity digest</span><span class="switch on"></span></div><div class="row" style="border:none;padding:var(--space-2) 0"><span style="font-size:var(--text-sm)">Incident emails</span><span class="switch on"></span></div></div>')
      + card('Data & Privacy','',{}).replace('<div class="card-body"></div>','<div class="card-body"><div class="stat-line"><span>Retention</span><span class="v">Configurable</span></div><div class="stat-line"><span>Region</span><span class="v">EU + US</span></div><div class="stat-line"><span>Backups</span><span class="v">Daily</span></div></div>')
    + `</div>`;
  }

  /* ============ VIEW BINDING (interactions) ============ */
  function bindView(ws, mod){
    // quick-action jumps
    $$('[data-jump]').forEach(el=>el.addEventListener('click',()=>location.hash='#/ws/'+ws.id+'/'+el.dataset.jump));
    // tabs
    $$('.tabs').forEach(group=>{
      const tt=group.querySelectorAll('.tab');
      tt.forEach(tab=>tab.addEventListener('click',()=>{
        tt.forEach(t=>t.classList.remove('active')); tab.classList.add('active');
        const wrap=group.closest('.view')||group.closest('.content');
        wrap.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('active', p.dataset.panel===tab.dataset.tab));
      }));
    });
    // toggles
    $$('.switch').forEach(sw=>sw.addEventListener('click',()=>{sw.classList.toggle('on');sw.setAttribute('aria-checked',sw.classList.contains('on'));}));
    // checkboxes
    $$('.checkbox').forEach(cb=>cb.addEventListener('click',()=>{cb.classList.toggle('checked');cb.innerHTML=cb.classList.contains('checked')?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M5 13l4 4L19 7"/></svg>':'';const task=cb.closest('.task');if(task)task.classList.toggle('done',cb.classList.contains('checked'));}));
    // buttons with toast
    $$('[data-toast]').forEach(b=>b.addEventListener('click',()=>flash(b.dataset.toast)));

    if(mod==='threats') bindThreats();
    if(mod==='stores') bindStores();
    if(mod==='integrations') bindIntegrations();
    if(mod==='marketing') bindMarketing();
    if(mod==='ai') bindAI();
  }

  /* ---- Threat interactions ---- */
  function bindThreats(){
    $$('.feed-config').forEach(b=>b.addEventListener('click',()=>{
      const i=+b.dataset.feed; const f=FEEDS[i];
      const activeTab=document.querySelector('.tabs .tab.active')?.dataset.tab;
      if(configuredFeeds.has(i)){ configuredFeeds.delete(i); flash(f.name+' feed removed'); }
      else { configuredFeeds.add(i); flash(f.name+' feed configured'); }
      const ws=currentWs(); if(ws){ content.innerHTML=renderThreats(ws); bindThreats(); restoreTab(activeTab); }
    }));
    const conf=$('#confRange');
    if(conf) conf.addEventListener('input',()=>{$('#confVal').textContent=conf.value;});
  }
  function restoreTab(tabId){ if(!tabId)return; document.querySelectorAll('.tabs').forEach(g=>{const t=g.querySelector('.tab[data-tab="'+tabId+'"]');if(t){g.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));t.classList.add('active');const wrap=g.closest('.content');wrap.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('active',p.dataset.panel===tabId));}}); }
  function currentWs(){ const p=location.hash.split('/').filter(Boolean); return WORKSPACES.find(w=>w.id===p[1]); }

  /* ---- Store interactions ---- */
  function bindStores(){
    $$('.store-conn').forEach(c=>c.addEventListener('click',()=>{
      const i=+c.dataset.store; const s=STORES[i];
      if(connectedStores.has(i)){ connectedStores.delete(i); flash(s.name+' disconnected'); }
      else { connectedStores.add(i); flash(s.name+' connected'); }
      const ws=currentWs(); content.innerHTML=renderStores(ws); bindStores();
    }));
  }

  /* ---- Marketing channel connect ---- */
  function bindMarketing(){
    $$('[data-connect-channel]').forEach(btn=>btn.addEventListener('click',()=>{
      flash('Opening integration catalog to connect '+btn.dataset.connectChannel+'…');
      const ws=currentWs(); location.hash='#/ws/'+ws.id+'/integrations';
    }));
    const aiGenOut=$('#aiGenOut');
    const drafts={email:['Subject: Your security posture, simplified\n\nHi Sarah,\n\nAs part of your GEM Enterprise plan, we are running a scheduled review of your exposure surface. Our AI Compliance Reviewer has flagged two items for attention this week. Would you like me to book a 20-minute walkthrough?\n\n— GEM Enterprise Team'],social:['Defend. Protect. Prevail.\n\nThis week we are highlighting how small businesses cut breach response time by 60% with a dedicated advisory layer.\n\n#CyberSecurity #GEMEnterprise #SmallBusiness'],ad:['Headline: Enterprise-grade protection for SMBs.\n\nSubhead: Advisory, monitoring, and compliance — in one workspace.\n\nCTA: Book your assessment today.']};
    let genTab='email';
    $$('.ai-gen-tab').forEach(tab=>tab.addEventListener('click',()=>{$$('.ai-gen-tab').forEach(t=>t.classList.remove('active'));tab.classList.add('active');genTab=tab.dataset.gen;if(aiGenOut)aiGenOut.innerHTML='<span class="typing">Select a format and generate a draft.</span>';}));
    const genBtn=$('#aiGenBtn');
    if(genBtn) genBtn.addEventListener('click',()=>{ if(!aiGenOut)return; skeleton(aiGenOut); setTimeout(()=>typeInto(aiGenOut, drafts[genTab]||drafts.email),650); });
  }

  /* ---- AI console ---- */
  function bindAI(){
    const out=$('#aiConsoleOut');
    const draft='Running compliance review for workspace: Infinite Wealth & Wellbeing\n\n[1/4] Eligibility check ……………………… PASSED\n[2/4] Scope & provider verification ……… PASSED\n[3/4] Jurisdiction check ……………………… PASSED\n[4/4] Contractual review ……………………… ACTION NEEDED\n\nSummary: 3 of 4 gates passed. Contractual review pending administrator approval. Draft briefing saved for review.';
    const b=$('#aiConsoleBtn');
    if(b) b.addEventListener('click',()=>{ if(!out)return; skeleton(out); setTimeout(()=>typeInto(out,draft),700); });
  }

  function skeleton(el){ el.innerHTML='<span class="skeleton-line"></span><span class="skeleton-line short"></span>'; }
  function typeInto(el,text){ clearInterval(typing); el.innerHTML='<span class="cursor"></span>'; let i=0; const cur=el.querySelector('.cursor'); typing=setInterval(()=>{ if(i>=text.length){clearInterval(typing);cur.remove();return;} el.insertBefore(document.createTextNode(text[i]),cur); i++; },12); }

  /* ---- Integrations catalog + connection manager ---- */
  function bindIntegrations(){
    let activeCat='all', q='';
    const counts={}; CATS.forEach(c=>counts[c.key]=0); allApps.forEach(a=>counts[a.category]++);
    const appGrid=$('#appGrid'), catChips=$('#catChips'), search=$('#appSearch'), resultCount=$('#resultCount'), featuredGrid=$('#featuredGrid');
    const cardHTML=a=>`<button class="app-card" data-name="${a.name}"><div class="app-card-top"><span class="app-icon" style="background:${a.color}">${a.initials}</span><div><div class="app-name">${a.name}</div><div class="app-cat">${a.catLabel}</div></div></div><div class="app-use">${a.use}</div><div class="app-foot"><span class="badge muted">Connect</span><span style="font-size:var(--text-xs);color:var(--color-text-faint)">OAuth</span></div></button>`;
    if(featuredGrid){ featuredGrid.innerHTML=allApps.filter(a=>a.featured).map(cardHTML).join(''); featuredGrid.querySelectorAll('.app-card').forEach(c=>c.addEventListener('click',()=>openDrawer(c.dataset.name))); }
    if(catChips){ catChips.innerHTML='<button class="chip active" data-cat="all">All <span class="count">'+allApps.length+'</span></button>'+CATS.map(c=>'<button class="chip" data-cat="'+c.key+'">'+c.label+' <span class="count">'+counts[c.key]+'</span></button>').join(''); catChips.querySelectorAll('.chip').forEach(ch=>ch.addEventListener('click',()=>{catChips.querySelectorAll('.chip').forEach(c=>c.classList.remove('active'));ch.classList.add('active');activeCat=ch.dataset.cat;renderGrid();})); }
    function renderGrid(){ let list=allApps; if(activeCat!=='all')list=list.filter(a=>a.category===activeCat); if(q)list=list.filter(a=>(a.name+' '+a.use+' '+a.catLabel).toLowerCase().includes(q)); if(resultCount)resultCount.textContent=list.length+' of '+allApps.length+' apps'; if(!list.length){appGrid.innerHTML='<div class="catalog-empty" style="grid-column:1/-1">No integrations match your search.</div>';return;} appGrid.innerHTML=list.map(cardHTML).join(''); appGrid.querySelectorAll('.app-card').forEach(c=>c.addEventListener('click',()=>openDrawer(c.dataset.name))); }
    if(search) search.addEventListener('input',()=>{q=search.value.toLowerCase().trim();renderGrid();});
    if(appGrid) renderGrid();
    // connection manager
    renderConn();
  }
  function renderConn(){
    const connList=$('#connList'), connEmpty=$('#connEmpty'), connBadge=$('#connBadge');
    if(connBadge) connBadge.textContent=connections.length;
    if(!connections.length){ if(connEmpty){connEmpty.style.display='';} if(connList){connList.innerHTML='';connList.style.display='none';} return; }
    if(connEmpty) connEmpty.style.display='none';
    if(connList){ connList.style.display=''; connList.innerHTML='<table><thead><tr><th class="th">Application</th><th class="th">Status</th><th class="th">Auth</th><th class="th">Last sync</th><th class="th"></th></tr></thead><tbody>'+connections.map(c=>'<tr><td class="td"><div style="display:flex;align-items:center;gap:10px"><span class="app-icon" style="width:28px;height:28px;background:'+c.color+'">'+c.initials+'</span><div><div class="cell-strong">'+c.name+'</div><div class="cell-muted" style="font-size:11px">'+c.catLabel+'</div></div></div></td><td class="td"><span class="badge success">Connected</span></td><td class="td cell-muted" style="font-size:12px">'+(c.auth||'OAuth 2.0')+'</td><td class="td cell-id">'+c.lastSync+'</td><td class="td" style="text-align:right"><button class="btn-link btn-sm" data-disc="'+c.name+'">Disconnect</button></td></tr>').join('')+'</tbody></table>'; connList.querySelectorAll('[data-disc]').forEach(b=>b.addEventListener('click',()=>{const i=connections.findIndex(c=>c.name===b.dataset.disc);if(i>-1){const n=connections[i].name;connections.splice(i,1);renderConn();flash(n+' disconnected');}})); }
  }

  /* ---- Drawer ---- */
  const drawer=$('#drawer'), overlay=$('#drawerOverlay');
  function openDrawer(name){ const a=allApps.find(x=>x.name===name); if(!a)return; $('#drawerIcon').textContent=a.initials; $('#drawerIcon').style.background=a.color; $('#drawerName').textContent=a.name; $('#drawerCat').textContent=a.catLabel; $('#drawerUse').textContent=a.use; $('#drawerActions').textContent='Sync records, trigger workflows, and read or write within the scopes you authorize.'; $('#drawerAuth').textContent=AUTH[name]||'OAuth 2.0 or API key'; $('#drawerScopes').innerHTML=['Read profile','Manage records','Send messages','Access audit data'].map(s=>'<span class="scope-chip">'+s+'</span>').join(''); const isConnected=connections.some(c=>c.name===a.name); const cb=$('#drawerConnect'); cb.textContent=isConnected?'Connected':'Connect'; cb.disabled=isConnected; drawer.classList.add('open');drawer.setAttribute('aria-hidden','false');overlay.classList.add('open'); }
  function closeDrawer(){ if(!drawer)return; drawer.classList.remove('open');drawer.setAttribute('aria-hidden','true');overlay.classList.remove('open'); }
  $('#drawerClose').addEventListener('click',closeDrawer);
  overlay.addEventListener('click',closeDrawer);
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeDrawer();});
  $('#drawerConnect').addEventListener('click',()=>{const name=$('#drawerName').textContent;const a=allApps.find(x=>x.name===name);if(!a)return;if(connections.some(c=>c.name===name))return;connections.push({...a,auth:AUTH[name]||'OAuth 2.0',lastSync:'Just now'});renderConn();flash(name+' connected');closeDrawer();});

  /* ============ THEME + INIT ============ */
  const tt=document.querySelector('[data-theme-toggle]'), root=document.documentElement;
  let theme=matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'; root.setAttribute('data-theme',theme);
  function setIcon(){ if(!tt)return; tt.innerHTML=theme==='dark'?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>':'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M1 12h2M21 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/></svg>'; }
  setIcon();
  tt&&tt.addEventListener('click',()=>{theme=theme==='dark'?'light':'dark';root.setAttribute('data-theme',theme);setIcon();});
  $('#menuBtn').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
  window.addEventListener('hashchange',route);
  route();
})();
